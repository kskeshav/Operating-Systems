# program number: 1
# Student Name: Keshav Singhal; Register Number: IMT2018511
# Date: 25/02/2021
# Description : Create the following types of a files using shell command.
#!/bin/bash

ln input.txt harlink.txt